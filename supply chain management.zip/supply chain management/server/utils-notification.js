const Notification = require('../models/Notification');
const WebSocket = require('ws');

let wss;

// Setup WebSocket server
function setupWebSocket(server) {
    wss = new WebSocket.Server({ server });
    
    wss.on('connection', (ws) => {
        console.log('New WebSocket connection');
        
        ws.on('close', () => {
            console.log('WebSocket connection closed');
        });
    });
}

// Send notification to user
async function sendNotification(userId, message, relatedEntity = null, relatedEntityId = null) {
    try {
        const notification = new Notification({
            user: userId,
            message,
            relatedEntity,
            relatedEntityId
        });
        
        await notification.save();
        
        // Broadcast to WebSocket clients
        if (wss) {
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN && client.userId === userId.toString()) {
                    client.send(JSON.stringify({
                        type: 'notification',
                        data: notification
                    }));
                }
            });
        }
        
        return notification;
    } catch (err) {
        console.error('Failed to send notification:', err);
        throw err;
    }
}

// Get unread notifications for user
async function getUnreadNotifications(userId) {
    try {
        return await Notification.find({
            user: userId,
            isRead: false
        }).sort('-createdAt');
    } catch (err) {
        console.error('Failed to fetch notifications:', err);
        throw err;
    }
}

// Mark notification as read
async function markAsRead(notificationId, userId) {
    try {
        return await Notification.findOneAndUpdate(
            { _id: notificationId, user: userId },
            { isRead: true },
            { new: true }
        );
    } catch (err) {
        console.error('Failed to mark notification as read:', err);
        throw err;
    }
}

module.exports = {
    setupWebSocket,
    sendNotification,
    getUnreadNotifications,
    markAsRead
};