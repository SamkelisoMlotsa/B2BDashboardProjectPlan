const app = require('./app');
const http = require('http');
const { setupWebSocket } = require('./utils/notifications');

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);

// Setup WebSocket for real-time notifications
setupWebSocket(server);

server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});