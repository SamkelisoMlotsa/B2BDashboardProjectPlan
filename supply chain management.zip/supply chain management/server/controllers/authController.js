const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { sendNotification } = require('../utils/notifications');

// Register a new user
exports.register = async (req, res) => {
    try {
        const { username, password, email, role, companyName, contactInfo } = req.body;
        
        // Check if user already exists
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: 'Username or email already exists' });
        }
        
        // Create new user
        const user = new User({
            username,
            password,
            email,
            role,
            companyName,
            contactInfo
        });
        
        await user.save();
        
        // Generate JWT token
        const token = jwt.sign(
            { userId: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );
        
        // Send welcome notification
        await sendNotification(user._id, `Welcome to Supply Chain Management System! Your account has been successfully created as a ${role}.`);
        
        res.status(201).json({ token, user: { id: user._id, username, email, role, companyName } });
    } catch (err) {
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

// Login user
exports.login = async (req, res) => {
    try {
        const { username, password, role } = req.body;
        
        // Find user by username
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        
        // Check role
        if (user.role !== role) {
            return res.status(401).json({ message: 'Invalid role for this user' });
        }
        
        // Check password
        const isMatch = await user.comparePassword(password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        
        // Generate JWT token
        const token = jwt.sign(
            { userId: user._id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn: '7d' }
        );
        
        res.json({ token, user: { id: user._id, username: user.username, email: user.email, role: user.role, companyName: user.companyName } });
    } catch (err) {
        res.status(500).json({ message: 'Login failed', error: err.message });
    }
};

// Get current user
exports.getCurrentUser = async (req, res) => {
    try {
        const user = await User.findById(req.userId).select('-password');
        res.json(user);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch user', error: err.message });
    }
};