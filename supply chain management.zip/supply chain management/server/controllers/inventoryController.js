const Inventory = require('../models/Inventory');
const Product = require('../models/Product');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { sendNotification } = require('../utils/notifications');

// Get inventory for current user
exports.getInventory = async (req, res) => {
    try {
        const inventory = await Inventory.find({ user: req.userId })
            .populate('product', 'name description price');
            
        res.json(inventory);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch inventory', error: err.message });
    }
};

// Update inventory item (for manufacturers)
exports.updateInventoryItem = async (req, res) => {
    try {
        const { productId, quantity, productionRate } = req.body;
        
        const inventoryItem = await Inventory.findOneAndUpdate(
            { user: req.userId, product: productId },
            { quantity, productionRate },
            { new: true, upsert: true }
        ).populate('product', 'name description price');
        
        res.json(inventoryItem);
    } catch (err) {
        res.status(500).json({ message: 'Failed to update inventory', error: err.message });
    }
};

// Check low stock (for retailers)
exports.checkLowStock = async (req, res) => {
    try {
        const lowStockItems = await Inventory.find({
            user: req.userId,
            quantity: { $lte: '$threshold' }
        }).populate('product', 'name description price');
        
        // Send notifications for low stock items
        if (lowStockItems.length > 0) {
            const message = `Low stock alert for ${lowStockItems.length} item(s). Please consider reordering.`;
            await sendNotification(req.userId, message, 'inventory');
        }
        
        res.json(lowStockItems);
    } catch (err) {
        res.status(500).json({ message: 'Failed to check low stock', error: err.message });
    }
};

// Get all products (for dropdowns)
exports.getProducts = async (req, res) => {
    try {
        const products = await Product.find({ createdBy: req.userId });
        res.json(products);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch products', error: err.message });
    }
};

// Create new product
exports.createProduct = async (req, res) => {
    try {
        const { name, description, price } = req.body;
        
        const product = new Product({
            name,
            description,
            price,
            createdBy: req.userId
        });
        
        await product.save();
        
        // Add to manufacturer's inventory
        if (req.userRole === 'manufacturer') {
            await Inventory.create({
                user: req.userId,
                product: product._id,
                quantity: 0
            });
        }
        
        res.status(201).json(product);
    } catch (err) {
        res.status(500).json({ message: 'Failed to create product', error: err.message });
    }
};