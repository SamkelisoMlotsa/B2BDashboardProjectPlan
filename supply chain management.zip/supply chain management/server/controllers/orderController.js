const Order = require('../models/Order');
const Inventory = require('../models/Inventory');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { sendNotification } = require('../utils/notifications');

// Create a new order (retailer)
exports.createOrder = async (req, res) => {
    try {
        const { manufacturerId, items } = req.body;
        
        // Validate manufacturer
        const manufacturer = await User.findById(manufacturerId);
        if (!manufacturer || manufacturer.role !== 'manufacturer') {
            return res.status(400).json({ message: 'Invalid manufacturer' });
        }
        
        // Create order
        const order = new Order({
            retailer: req.userId,
            manufacturer: manufacturerId,
            items,
            status: 'pending'
        });
        
        await order.save();
        
        // Send notification to manufacturer
        const retailer = await User.findById(req.userId);
        await sendNotification(
            manufacturerId,
            `New order received from ${retailer.companyName}`,
            'order',
            order._id
        );
        
        res.status(201).json(order);
    } catch (err) {
        res.status(500).json({ message: 'Failed to create order', error: err.message });
    }
};

// Get orders for current user
exports.getOrders = async (req, res) => {
    try {
        let query = {};
        
        if (req.userRole === 'retailer') {
            query.retailer = req.userId;
        } else if (req.userRole === 'manufacturer') {
            query.manufacturer = req.userId;
        }
        
        if (req.query.status) {
            query.status = req.query.status;
        }
        
        const orders = await Order.find(query)
            .populate('retailer', 'companyName')
            .populate('manufacturer', 'companyName')
            .sort('-createdAt');
            
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch orders', error: err.message });
    }
};

// Get order by ID
exports.getOrderById = async (req, res) => {
    try {
        const order = await Order.findById(req.params.id)
            .populate('retailer', 'companyName contactInfo')
            .populate('manufacturer', 'companyName contactInfo')
            .populate('items.product', 'name description price');
            
        if (!order) {
            return res.status(404).json({ message: 'Order not found' });
        }
        
        // Check if user is authorized to view this order
        if (order.retailer._id.toString() !== req.userId && 
            order.manufacturer._id.toString() !== req.userId) {
            return res.status(403).json({ message: 'Unauthorized to view this order' });
        }
        
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch order', error: err.message });
    }
};

// Update order status (manufacturer)
exports.updateOrderStatus = async (req, res) => {
    try {
        const { status } = req.body;
        
        const order = await Order.findById(req.params.id);
        if (!order) {
            return res.status(404).json({ message: 'Order not found' });
        }
        
        // Check if user is the manufacturer of this order
        if (order.manufacturer.toString() !== req.userId) {
            return res.status(403).json({ message: 'Unauthorized to update this order' });
        }
        
        // Process order (reduce inventory)
        if (status === 'processing' && order.status === 'pending') {
            // Check inventory
            for (const item of order.items) {
                const inventory = await Inventory.findOne({
                    user: req.userId,
                    product: item.product
                });
                
                if (!inventory || inventory.quantity < item.quantity) {
                    return res.status(400).json({ 
                        message: 'Insufficient inventory to process this order'
                    });
                }
            }
            
            // Reduce inventory
            for (const item of order.items) {
                await Inventory.findOneAndUpdate(
                    { user: req.userId, product: item.product },
                    { $inc: { quantity: -item.quantity } }
                );
            }
        }
        
        // Update status
        order.status = status;
        if (status === 'shipped') {
            order.deliveryDate = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000); // 3 days from now
        }
        
        await order.save();
        
        // Send notification to retailer
        await sendNotification(
            order.retailer,
            `Your order #${order._id} status has been updated to ${status}`,
            'order',
            order._id
        );
        
        res.json(order);
    } catch (err) {
        res.status(500).json({ message: 'Failed to update order', error: err.message });
    }
};

// Get order history with filters
exports.getOrderHistory = async (req, res) => {
    try {
        let query = { retailer: req.userId };
        
        // Apply time filters
        if (req.query.filter) {
            const now = new Date();
            let startDate;
            
            switch (req.query.filter) {
                case 'lastMonth':
                    startDate = new Date(now.setMonth(now.getMonth() - 1));
                    break;
                case 'lastQuarter':
                    startDate = new Date(now.setMonth(now.getMonth() - 3));
                    break;
                case 'lastYear':
                    startDate = new Date(now.setFullYear(now.getFullYear() - 1));
                    break;
                default:
                    // No date filter for 'all'
                    break;
            }
            
            if (startDate) {
                query.orderDate = { $gte: startDate };
            }
        }
        
        const orders = await Order.find(query)
            .populate('manufacturer', 'companyName')
            .sort('-orderDate');
            
        res.json(orders);
    } catch (err) {
        res.status(500).json({ message: 'Failed to fetch order history', error: err.message });
    }
};