const express = require('express');
const router = express.Router();
const inventoryController = require('../controllers/inventoryController');
const auth = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Get inventory
router.get('/', inventoryController.getInventory);

// Check low stock
router.get('/low-stock', inventoryController.checkLowStock);

// Update inventory
router.put('/', inventoryController.updateInventoryItem);

// Product management
router.get('/products', inventoryController.getProducts);
router.post('/products', inventoryController.createProduct);

module.exports = router;