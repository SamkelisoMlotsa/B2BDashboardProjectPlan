const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Product',
        required: true
    },
    quantity: {
        type: Number,
        required: true,
        min: 0
    },
    // For retailers
    threshold: {
        type: Number,
        default: 10,
        min: 0
    },
    // For manufacturers
    productionRate: {
        type: Number,
        min: 0
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

// Ensure each user has only one inventory item per product
inventorySchema.index({ user: 1, product: 1 }, { unique: true });

module.exports = mongoose.model('Inventory', inventorySchema);