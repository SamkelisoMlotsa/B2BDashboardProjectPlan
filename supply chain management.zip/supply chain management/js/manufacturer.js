// DOM Elements
const inventoryTable = document.getElementById('inventoryTable').querySelector('tbody');
const ordersTable = document.getElementById('ordersTable').querySelector('tbody');
const refreshInventoryBtn = document.getElementById('refreshInventory');
const updateInventoryBtn = document.getElementById('updateInventoryBtn');
const orderFilter = document.getElementById('orderFilter');
const navLinks = document.querySelectorAll('nav a');
const updateInventoryModal = document.getElementById('updateInventoryModal');
const updateInventoryForm = document.getElementById('updateInventoryForm');
const updateProductSelect = document.getElementById('updateProductSelect');
const inventoryQuantity = document.getElementById('inventoryQuantity');
const closeUpdateModal = updateInventoryModal.querySelector('.close');
const orderDetailModal = document.getElementById('orderDetailModal');
const orderDetailContent = document.getElementById('orderDetailContent');
const processOrderBtn = document.getElementById('processOrderBtn');
const shipOrderBtn = document.getElementById('shipOrderBtn');
const cancelOrderBtn = document.getElementById('cancelOrderBtn');
const closeOrderModal = orderDetailModal.querySelector('.close');
const productionForm = document.getElementById('productionForm');
const productSelect = document.getElementById('productSelect');
const productionRate = document.getElementById('productionRate');
const totalCapacitySpan = document.getElementById('totalCapacity');
const ordersInQueueSpan = document.getElementById('ordersInQueue');
const estFulfillmentSpan = document.getElementById('estFulfillment');

// Data
let products = [];
let inventory = [];
let currentOrders = [];
let currentOrderDetails = null;

// Initialize manufacturer dashboard
async function initManufacturerDashboard() {
    // Check authentication
    if (!authToken || !currentUser || currentUser.role !== 'manufacturer') {
        window.location.href = 'login.html';
        return;
    }
    
    // Set up navigation
    setupNavigation();
    
    // Load initial data
    await loadData();
    
    // Set up event listeners
    setupEventListeners();
    
    // Show inventory section by default
    showSection('inventory');
}

// Set up navigation
function setupNavigation() {
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            showSection(section);
            
            // Update active class
            navLinks.forEach(navLink => navLink.classList.remove('active'));
            link.classList.add('active');
        });
    });
}

// Show a specific section
function showSection(sectionId) {
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.classList.remove('active');
    });
    
    document.getElementById(sectionId).classList.add('active');
    
    // Load section data if needed
    if (sectionId === 'orders') {
        loadCurrentOrders();
    } else if (sectionId === 'production') {
        loadProductionStats();
    }
}

// Load all necessary data
async function loadData() {
    try {
        // Load inventory
        const inventoryData = await makeAuthRequest('/inventory');
        inventory = inventoryData || [];
        
        // Load products
        const productsData = await makeAuthRequest('/inventory/products');
        products = productsData || [];
        
        // Render inventory
        renderInventory();
        
        // Populate product dropdowns
        populateProductDropdowns();
    } catch (err) {
        console.error('Failed to load data:', err);
        alert('Failed to load data. Please try again.');
    }
}

// Render inventory table
function renderInventory() {
    inventoryTable.innerHTML = '';
    
    if (inventory.length === 0) {
        inventoryTable.innerHTML = '<tr><td colspan="6">No inventory items found</td></tr>';
        return;
    }
    
    inventory.forEach(item => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${item.product._id}</td>
            <td>${item.product.name}</td>
            <td>${item.product.description || 'N/A'}</td>
            <td>${item.quantity}</td>
            <td>${item.productionRate || 'N/A'}</td>
            <td>
                <button class="update-inventory" data-id="${item.product._id}">Update</button>
            </td>
        `;
        
        inventoryTable.appendChild(row);
    });
    
    // Set up event listeners for update buttons
    document.querySelectorAll('.update-inventory').forEach(btn => {
        btn.addEventListener('click', () => {
            const productId = btn.getAttribute('data-id');
            openUpdateInventoryModal(productId);
        });
    });
}

// Populate product dropdowns
function populateProductDropdowns() {
    updateProductSelect.innerHTML = '<option value="">Select Product</option>';
    productSelect.innerHTML = '<option value="">Select Product</option>';
    
    products.forEach(product => {
        const option1 = document.createElement('option');
        option1.value = product._id;
        option1.textContent = product.name;
        updateProductSelect.appendChild(option1.cloneNode(true));
        
        const option2 = option1.cloneNode(true);
        productSelect.appendChild(option2);
    });
}

// Open update inventory modal
function openUpdateInventoryModal(productId) {
    const item = inventory.find(i => i.product._id === productId);
    
    if (item) {
        updateProductSelect.value = productId;
        inventoryQuantity.value = item.quantity;
        updateInventoryModal.classList.remove('hidden');
    }
}

// Set up event listeners
function setupEventListeners() {
    // Refresh inventory
    if (refreshInventoryBtn) {
        refreshInventoryBtn.addEventListener('click', loadData);
    }
    
    // Update inventory button
    if (updateInventoryBtn) {
        updateInventoryBtn.addEventListener('click', () => {
            updateInventoryModal.classList.remove('hidden');
            updateProductSelect.value = '';
            inventoryQuantity.value = '';
        });
    }
    
    // Close update modal
    if (closeUpdateModal) {
        closeUpdateModal.addEventListener('click', () => {
            updateInventoryModal.classList.add('hidden');
        });
    }
    
    // Update inventory form
    if (updateInventoryForm) {
        updateInventoryForm.addEventListener('submit', handleInventoryUpdate);
    }
    
    // Order filter
    if (orderFilter) {
        orderFilter.addEventListener('change', loadCurrentOrders);
    }
    
    // Production form
    if (productionForm) {
        productionForm.addEventListener('submit', handleProductionRateUpdate);
    }
    
    // Close order detail modal
    if (closeOrderModal) {
        closeOrderModal.addEventListener('click', () => {
            orderDetailModal.classList.add('hidden');
        });
    }
    
    // Process order button
    if (processOrderBtn) {
        processOrderBtn.addEventListener('click', () => {
            updateOrderStatus('processing');
        });
    }
    
    // Ship order button
    if (shipOrderBtn) {
        shipOrderBtn.addEventListener('click', () => {
            updateOrderStatus('shipped');
        });
    }
    
    // Cancel order button
    if (cancelOrderBtn) {
        cancelOrderBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to cancel this order?')) {
                updateOrderStatus('cancelled');
            }
        });
    }
}

// Handle inventory update
async function handleInventoryUpdate(e) {
    e.preventDefault();
    
    const productId = updateProductSelect.value;
    const quantity = parseInt(inventoryQuantity.value);
    
    if (!productId || isNaN(quantity)) {
        alert('Please select a product and enter a valid quantity');
        return;
    }
    
    try {
        const response = await makeAuthRequest('/inventory', 'PUT', {
            productId,
            quantity
        });
        
        if (response) {
            alert('Inventory updated successfully!');
            updateInventoryModal.classList.add('hidden');
            loadData();
        }
    } catch (err) {
        console.error('Failed to update inventory:', err);
        alert('Failed to update inventory: ' + err.message);
    }
}

// Handle production rate update
async function handleProductionRateUpdate(e) {
    e.preventDefault();
    
    const productId = productSelect.value;
    const rate = parseInt(productionRate.value);
    
    if (!productId || isNaN(rate)) {
        alert('Please select a product and enter a valid production rate');
        return;
    }
    
    try {
        const response = await makeAuthRequest('/inventory', 'PUT', {
            productId,
            productionRate: rate
        });
        
        if (response) {
            alert('Production rate updated successfully!');
            productionForm.reset();
            loadData();
            loadProductionStats();
        }
    } catch (err) {
        console.error('Failed to update production rate:', err);
        alert('Failed to update production rate: ' + err.message);
    }
}

// Load current orders
async function loadCurrentOrders() {
    try {
        const filter = orderFilter ? orderFilter.value : 'all';
        const orders = await makeAuthRequest(`/orders?status=${filter}`);
        currentOrders = orders || [];
        renderCurrentOrders();
    } catch (err) {
        console.error('Failed to load orders:', err);
        alert('Failed to load orders. Please try again.');
    }
}

// Render current orders
function renderCurrentOrders() {
    ordersTable.innerHTML = '';
    
    if (currentOrders.length === 0) {
        ordersTable.innerHTML = '<tr><td colspan="7">No orders found</td></tr>';
        return;
    }
    
    currentOrders.forEach(order => {
        const row = document.createElement('tr');
        
        const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0);
        
        row.innerHTML = `
            <td>${order._id}</td>
            <td>${order.retailer.companyName}</td>
            <td>${new Date(order.orderDate).toLocaleDateString()}</td>
            <td class="status-${order.status}">${order.status}</td>
            <td>${totalItems}</td>
            <td>$${order.totalAmount.toFixed(2)}</td>
            <td>
                <button class="view-order" data-id="${order._id}">View</button>
            </td>
        `;
        
        ordersTable.appendChild(row);
    });
    
    // Set up event listeners for view buttons
    document.querySelectorAll('.view-order').forEach(btn => {
        btn.addEventListener('click', () => {
            const orderId = btn.getAttribute('data-id');
            viewOrderDetails(orderId);
        });
    });
}

// View order details
async function viewOrderDetails(orderId) {
    try {
        const order = await makeAuthRequest(`/orders/${orderId}`);
        
        if (order) {
            currentOrderDetails = order;
            renderOrderDetails(order);
            orderDetailModal.classList.remove('hidden');
            
            // Update button visibility based on order status
            processOrderBtn.style.display = order.status === 'pending' ? 'block' : 'none';
            shipOrderBtn.style.display = order.status === 'processing' ? 'block' : 'none';
            cancelOrderBtn.style.display = order.status !== 'cancelled' && order.status !== 'delivered' ? 'block' : 'none';
        }
    } catch (err) {
        console.error('Failed to fetch order details:', err);
        alert('Failed to fetch order details. Please try again.');
    }
}

// Render order details
function renderOrderDetails(order) {
    orderDetailContent.innerHTML = '';
    
    // Order summary
    const summary = document.createElement('div');
    summary.className = 'order-summary';
    
    const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0);
    
    summary.innerHTML = `
        <h3>Order #${order._id}</h3>
        <p><strong>Retailer:</strong> ${order.retailer.companyName}</p>
        <p><strong>Order Date:</strong> ${new Date(order.orderDate).toLocaleString()}</p>
        <p><strong>Status:</strong> <span class="status-${order.status}">${order.status}</span></p>
        <p><strong>Total Items:</strong> ${totalItems}</p>
        <p><strong>Total Amount:</strong> $${order.totalAmount.toFixed(2)}</p>
    `;
    
    orderDetailContent.appendChild(summary);
    
    // Order items
    const itemsHeader = document.createElement('h4');
    itemsHeader.textContent = 'Order Items';
    orderDetailContent.appendChild(itemsHeader);
    
    const itemsTable = document.createElement('table');
    itemsTable.className = 'order-items-table';
    
    const thead = document.createElement('thead');
    thead.innerHTML = `
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Total</th>
        </tr>
    `;
    itemsTable.appendChild(thead);
    
    const tbody = document.createElement('tbody');
    order.items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.product.name}</td>
            <td>${item.quantity}</td>
            <td>$${item.unitPrice.toFixed(2)}</td>
            <td>$${(item.quantity * item.unitPrice).toFixed(2)}</td>
        `;
        tbody.appendChild(row);
    });
    itemsTable.appendChild(tbody);
    
    orderDetailContent.appendChild(itemsTable);
}

// Update order status
async function updateOrderStatus(status) {
    if (!currentOrderDetails) return;
    
    try {
        const response = await makeAuthRequest(`/orders/${currentOrderDetails._id}/status`, 'PUT', {
            status
        });
        
        if (response) {
            alert(`Order status updated to ${status}`);
            orderDetailModal.classList.add('hidden');
            loadCurrentOrders();
        }
    } catch (err) {
        console.error('Failed to update order status:', err);
        alert('Failed to update order status: ' + err.message);
    }
}

// Load production statistics
async function loadProductionStats() {
    try {
        // Calculate total capacity
        const totalCapacity = inventory.reduce((sum, item) => sum + (item.quantity || 0), 0);
        totalCapacitySpan.textContent = `${totalCapacity} units`;
        
        // Count orders in queue
        const orders = await makeAuthRequest('/orders?status=pending&status=processing');
        ordersInQueueSpan.textContent = orders ? orders.length : 0;
        
        // Calculate estimated fulfillment time
        // This is a simplified calculation - in a real app, it would consider production rates
        const pendingItems = orders ? 
            orders.reduce((sum, order) => sum + order.items.reduce((s, item) => s + item.quantity, 0), 0) : 0;
        
        const dailyProduction = inventory.reduce((sum, item) => sum + (item.productionRate || 0), 0);
        const estDays = dailyProduction > 0 ? Math.ceil(pendingItems / dailyProduction) : 0;
        
        estFulfillmentSpan.textContent = estDays > 0 ? `${estDays} days` : 'N/A';
    } catch (err) {
        console.error('Failed to load production stats:', err);
    }
}

// Initialize the manufacturer dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', initManufacturerDashboard);