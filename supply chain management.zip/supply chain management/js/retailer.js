// DOM Elements
const inventoryTable = document.getElementById('inventoryTable').querySelector('tbody');
const ordersTable = document.getElementById('ordersTable').querySelector('tbody');
const historyTable = document.getElementById('historyTable').querySelector('tbody');
const lowStockAlert = document.getElementById('lowStockAlert');
const lowStockItems = document.getElementById('lowStockItems');
const refreshInventoryBtn = document.getElementById('refreshInventory');
const orderSuppliesBtn = document.getElementById('orderSuppliesBtn');
const orderModal = document.getElementById('orderModal');
const closeModal = document.querySelector('.close');
const orderForm = document.getElementById('orderForm');
const manufacturerSelect = document.getElementById('manufacturerSelect');
const orderItemsBody = document.getElementById('orderItemsBody');
const addOrderItemBtn = document.getElementById('addOrderItem');
const totalItemsSpan = document.getElementById('totalItems');
const totalAmountSpan = document.getElementById('totalAmount');
const historyFilter = document.getElementById('historyFilter');
const navLinks = document.querySelectorAll('nav a');

// Data
let products = [];
let manufacturers = [];
let inventory = [];
let currentOrders = [];

// Initialize retailer dashboard
async function initRetailerDashboard() {
    // Check authentication
    if (!authToken || !currentUser || currentUser.role !== 'retailer') {
        window.location.href = 'login.html';
        return;
    }
    
    // Set up navigation
    setupNavigation();
    
    // Load initial data
    await loadData();
    
    // Set up event listeners
    setupEventListeners();
    
    // Show inventory section by default
    showSection('inventory');
    
    // Check for low stock
    checkLowStock();
}

// Set up navigation
function setupNavigation() {
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            showSection(section);
            
            // Update active class
            navLinks.forEach(navLink => navLink.classList.remove('active'));
            link.classList.add('active');
        });
    });
}

// Show a specific section
function showSection(sectionId) {
    document.querySelectorAll('.dashboard-section').forEach(section => {
        section.classList.remove('active');
    });
    
    document.getElementById(sectionId).classList.add('active');
    
    // Load section data if needed
    if (sectionId === 'orders') {
        loadCurrentOrders();
    } else if (sectionId === 'history') {
        loadOrderHistory();
    }
}

// Load all necessary data
async function loadData() {
    try {
        // Load inventory
        const inventoryData = await makeAuthRequest('/inventory');
        inventory = inventoryData || [];
        
        // Load manufacturers
        const manufacturersData = await makeAuthRequest('/users?role=manufacturer');
        manufacturers = manufacturersData || [];
        
        // Load products (from manufacturers)
        const productsData = await makeAuthRequest('/inventory/products');
        products = productsData || [];
        
        // Render inventory
        renderInventory();
        
        // Populate manufacturer dropdown
        populateManufacturerDropdown();
    } catch (err) {
        console.error('Failed to load data:', err);
        alert('Failed to load data. Please try again.');
    }
}

// Render inventory table
function renderInventory() {
    inventoryTable.innerHTML = '';
    
    if (inventory.length === 0) {
        inventoryTable.innerHTML = '<tr><td colspan="6">No inventory items found</td></tr>';
        return;
    }
    
    inventory.forEach(item => {
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${item.product._id}</td>
            <td>${item.product.name}</td>
            <td>${item.product.description || 'N/A'}</td>
            <td>${item.quantity}</td>
            <td>${item.threshold || 'N/A'}</td>
            <td class="${item.quantity <= item.threshold ? 'low-stock' : ''}">
                ${item.quantity <= item.threshold ? 'Low Stock' : 'In Stock'}
            </td>
        `;
        
        inventoryTable.appendChild(row);
    });
}

// Populate manufacturer dropdown
function populateManufacturerDropdown() {
    manufacturerSelect.innerHTML = '<option value="">Select Manufacturer</option>';
    
    manufacturers.forEach(manufacturer => {
        const option = document.createElement('option');
        option.value = manufacturer._id;
        option.textContent = manufacturer.companyName;
        manufacturerSelect.appendChild(option);
    });
}

// Check for low stock items
async function checkLowStock() {
    try {
        const lowStockData = await makeAuthRequest('/inventory/low-stock');
        
        if (lowStockData && lowStockData.length > 0) {
            lowStockAlert.classList.remove('hidden');
            
            lowStockItems.innerHTML = '';
            lowStockData.forEach(item => {
                const div = document.createElement('div');
                div.className = 'low-stock-item';
                div.innerHTML = `
                    <strong>${item.product.name}</strong>: 
                    ${item.quantity} left (threshold: ${item.threshold})
                `;
                lowStockItems.appendChild(div);
            });
        } else {
            lowStockAlert.classList.add('hidden');
        }
    } catch (err) {
        console.error('Failed to check low stock:', err);
    }
}

// Set up event listeners
function setupEventListeners() {
    // Refresh inventory
    if (refreshInventoryBtn) {
        refreshInventoryBtn.addEventListener('click', async () => {
            await loadData();
            checkLowStock();
        });
    }
    
    // Order supplies button
    if (orderSuppliesBtn) {
        orderSuppliesBtn.addEventListener('click', () => {
            orderModal.classList.remove('hidden');
            resetOrderForm();
        });
    }
    
    // Close modal
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            orderModal.classList.add('hidden');
        });
    }
    
    // Add order item
    if (addOrderItemBtn) {
        addOrderItemBtn.addEventListener('click', addOrderItemRow);
    }
    
    // Order form submission
    if (orderForm) {
        orderForm.addEventListener('submit', handleOrderSubmit);
    }
    
    // History filter
    if (historyFilter) {
        historyFilter.addEventListener('change', loadOrderHistory);
    }
}

// Reset order form
function resetOrderForm() {
    orderItemsBody.innerHTML = '';
    totalItemsSpan.textContent = '0';
    totalAmountSpan.textContent = '0.00';
    addOrderItemRow();
}

// Add a new order item row
function addOrderItemRow() {
    const row = document.createElement('tr');
    row.className = 'order-item-row';
    
    row.innerHTML = `
        <td>
            <select class="product-select" required>
                <option value="">Select Product</option>
                ${products.map(p => `<option value="${p._id}" data-price="${p.price}">${p.name} ($${p.price})</option>`).join('')}
            </select>
        </td>
        <td class="available-quantity">-</td>
        <td><input type="number" class="quantity" min="1" value="1" required></td>
        <td class="unit-price">-</td>
        <td class="item-total">-</td>
        <td><button type="button" class="remove-item">Remove</button></td>
    `;
    
    orderItemsBody.appendChild(row);
    
    // Set up event listeners for the new row
    const productSelect = row.querySelector('.product-select');
    const quantityInput = row.querySelector('.quantity');
    const removeBtn = row.querySelector('.remove-item');
    
    productSelect.addEventListener('change', () => {
        updateProductDetails(row);
        calculateOrderTotal();
    });
    
    quantityInput.addEventListener('input', () => {
        updateItemTotal(row);
        calculateOrderTotal();
    });
    
    removeBtn.addEventListener('click', () => {
        row.remove();
        calculateOrderTotal();
    });
}

// Update product details when selected
function updateProductDetails(row) {
    const productSelect = row.querySelector('.product-select');
    const selectedOption = productSelect.options[productSelect.selectedIndex];
    const productId = productSelect.value;
    
    if (!productId) {
        row.querySelector('.available-quantity').textContent = '-';
        row.querySelector('.unit-price').textContent = '-';
        row.querySelector('.item-total').textContent = '-';
        return;
    }
    
    const price = selectedOption.getAttribute('data-price');
    row.querySelector('.unit-price').textContent = price;
    
    // Find manufacturer's inventory for this product
    const manufacturerId = manufacturerSelect.value;
    if (manufacturerId) {
        // In a real app, we'd fetch the manufacturer's inventory for this product
        row.querySelector('.available-quantity').textContent = 'Checking...';
        
        // Simulate checking inventory
        setTimeout(() => {
            // This would be an API call in a real app
            row.querySelector('.available-quantity').textContent = '100+'; // Placeholder
        }, 500);
    }
    
    updateItemTotal(row);
}

// Update item total
function updateItemTotal(row) {
    const quantity = parseInt(row.querySelector('.quantity').value) || 0;
    const price = parseFloat(row.querySelector('.unit-price').textContent) || 0;
    const total = quantity * price;
    
    row.querySelector('.item-total').textContent = total.toFixed(2);
}

// Calculate order total
function calculateOrderTotal() {
    let totalItems = 0;
    let totalAmount = 0;
    
    document.querySelectorAll('.order-item-row').forEach(row => {
        const quantity = parseInt(row.querySelector('.quantity').value) || 0;
        const price = parseFloat(row.querySelector('.unit-price').textContent) || 0;
        
        totalItems += quantity;
        totalAmount += quantity * price;
    });
    
    totalItemsSpan.textContent = totalItems;
    totalAmountSpan.textContent = totalAmount.toFixed(2);
}

// Handle order submission
async function handleOrderSubmit(e) {
    e.preventDefault();
    
    const manufacturerId = manufacturerSelect.value;
    if (!manufacturerId) {
        alert('Please select a manufacturer');
        return;
    }
    
    const orderItems = [];
    let isValid = true;
    
    document.querySelectorAll('.order-item-row').forEach(row => {
        const productSelect = row.querySelector('.product-select');
        const productId = productSelect.value;
        const quantity = parseInt(row.querySelector('.quantity').value);
        const price = parseFloat(row.querySelector('.unit-price').textContent);
        
        if (!productId || !quantity || !price) {
            isValid = false;
            return;
        }
        
        orderItems.push({
            productId,
            quantity,
            unitPrice: price
        });
    });
    
    if (!isValid || orderItems.length === 0) {
        alert('Please add at least one valid order item');
        return;
    }
    
    try {
        const response = await makeAuthRequest('/orders', 'POST', {
            manufacturerId,
            items: orderItems
        });
        
        if (response) {
            alert('Order placed successfully!');
            orderModal.classList.add('hidden');
            loadCurrentOrders();
        }
    } catch (err) {
        console.error('Failed to place order:', err);
        alert('Failed to place order: ' + err.message);
    }
}

// Load current orders
async function loadCurrentOrders() {
    try {
        const orders = await makeAuthRequest('/orders?status=pending&status=processing&status=shipped');
        currentOrders = orders || [];
        renderCurrentOrders();
    } catch (err) {
        console.error('Failed to load orders:', err);
        alert('Failed to load orders. Please try again.');
    }
}

// Render current orders
function renderCurrentOrders() {
    ordersTable.innerHTML = '';
    
    if (currentOrders.length === 0) {
        ordersTable.innerHTML = '<tr><td colspan="7">No current orders found</td></tr>';
        return;
    }
    
    currentOrders.forEach(order => {
        const row = document.createElement('tr');
        
        const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0);
        
        row.innerHTML = `
            <td>${order._id}</td>
            <td>${order.manufacturer.companyName}</td>
            <td>${new Date(order.orderDate).toLocaleDateString()}</td>
            <td class="status-${order.status}">${order.status}</td>
            <td>${totalItems}</td>
            <td>$${order.totalAmount.toFixed(2)}</td>
            <td>
                <button class="view-order" data-id="${order._id}">View</button>
            </td>
        `;
        
        ordersTable.appendChild(row);
    });
    
    // Set up event listeners for view buttons
    document.querySelectorAll('.view-order').forEach(btn => {
        btn.addEventListener('click', () => {
            const orderId = btn.getAttribute('data-id');
            viewOrderDetails(orderId);
        });
    });
}

// View order details
async function viewOrderDetails(orderId) {
    try {
        const order = await makeAuthRequest(`/orders/${orderId}`);
        
        if (order) {
            // Show order details in a modal or separate page
            alert(`Order Details:\nStatus: ${order.status}\nItems: ${order.items.length}\nTotal: $${order.totalAmount.toFixed(2)}`);
        }
    } catch (err) {
        console.error('Failed to fetch order details:', err);
        alert('Failed to fetch order details. Please try again.');
    }
}

// Load order history
async function loadOrderHistory() {
    try {
        const filter = historyFilter ? historyFilter.value : 'all';
        const history = await makeAuthRequest(`/orders/history?filter=${filter}`);
        renderOrderHistory(history || []);
    } catch (err) {
        console.error('Failed to load order history:', err);
        alert('Failed to load order history. Please try again.');
    }
}

// Render order history
function renderOrderHistory(history) {
    historyTable.innerHTML = '';
    
    if (history.length === 0) {
        historyTable.innerHTML = '<tr><td colspan="6">No order history found</td></tr>';
        return;
    }
    
    history.forEach(order => {
        const row = document.createElement('tr');
        
        const totalItems = order.items.reduce((sum, item) => sum + item.quantity, 0);
        
        row.innerHTML = `
            <td>${order._id}</td>
            <td>${order.manufacturer.companyName}</td>
            <td>${new Date(order.orderDate).toLocaleDateString()}</td>
            <td class="status-${order.status}">${order.status}</td>
            <td>${totalItems}</td>
            <td>$${order.totalAmount.toFixed(2)}</td>
        `;
        
        historyTable.appendChild(row);
    });
}

// Initialize the retailer dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', initRetailerDashboard);