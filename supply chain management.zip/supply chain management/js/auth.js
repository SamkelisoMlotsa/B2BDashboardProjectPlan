// DOM Elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const logoutBtn = document.getElementById('logoutBtn');

// Base API URL
const API_BASE_URL = 'http://localhost:5000/api';

// Token and user data
let authToken = localStorage.getItem('authToken');
let currentUser = JSON.parse(localStorage.getItem('currentUser'));

// Initialize WebSocket connection
let socket;

// Initialize app
function initApp() {
    // Check if user is logged in
    if (authToken && currentUser) {
        // Redirect to appropriate dashboard
        if (currentUser.role === 'retailer') {
            window.location.href = 'retailer-dashboard.html';
        } else {
            window.location.href = 'manufacturer-dashboard.html';
        }
    } else {
        // Clear any existing token and user data
        localStorage.removeItem('authToken');
        localStorage.removeItem('currentUser');
    }
    
    // Setup event listeners
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // Connect WebSocket if on dashboard
    if (window.location.pathname.includes('dashboard')) {
        connectWebSocket();
    }
}

// Handle login
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, role })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Login failed');
        }
        
        // Store token and user data
        localStorage.setItem('authToken', data.token);
        localStorage.setItem('currentUser', JSON.stringify(data.user));
        
        // Redirect to dashboard
        if (data.user.role === 'retailer') {
            window.location.href = 'retailer-dashboard.html';
        } else {
            window.location.href = 'manufacturer-dashboard.html';
        }
    } catch (err) {
        alert(err.message);
    }
}

// Handle registration
async function handleRegister(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;
    const role = document.getElementById('role').value;
    const companyName = document.getElementById('companyName').value;
    const phone = document.getElementById('phone').value;
    const address = document.getElementById('address').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username,
                password,
                email,
                role,
                companyName,
                contactInfo: {
                    phone,
                    address
                }
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Registration failed');
        }
        
        alert('Registration successful! Please login.');
        window.location.href = 'login.html';
    } catch (err) {
        alert(err.message);
    }
}

// Handle logout
function handleLogout() {
    // Close WebSocket connection
    if (socket) {
        socket.close();
    }
    
    // Clear storage and redirect to login
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    window.location.href = 'login.html';
}

// Connect WebSocket for real-time updates
function connectWebSocket() {
    if (!authToken) return;
    
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${wsProtocol}//${window.location.host}/ws`;
    
    socket = new WebSocket(wsUrl);
    
    // Add user ID to WebSocket connection
    socket.onopen = () => {
        socket.send(JSON.stringify({
            type: 'auth',
            token: authToken
        }));
    };
    
    // Handle incoming messages
    socket.onmessage = (event) => {
        const message = JSON.parse(event.data);
        
        if (message.type === 'notification') {
            showNotification(message.data);
        }
    };
    
    socket.onerror = (error) => {
        console.error('WebSocket error:', error);
    };
    
    socket.onclose = () => {
        console.log('WebSocket connection closed');
    };
}

// Show notification to user
function showNotification(notification) {
    // Implement notification UI (e.g., toast notification)
    console.log('New notification:', notification);
    
    // Example: Show a toast notification
    const toast = document.createElement('div');
    toast.className = 'toast-notification';
    toast.textContent = notification.message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Make authenticated API requests
async function makeAuthRequest(url, method = 'GET', body = null) {
    try {
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        };
        
        const options = {
            method,
            headers
        };
        
        if (body) {
            options.body = JSON.stringify(body);
        }
        
        const response = await fetch(`${API_BASE_URL}${url}`, options);
        
        if (response.status === 401) {
            // Token expired or invalid
            handleLogout();
            return null;
        }
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || 'Request failed');
        }
        
        return data;
    } catch (err) {
        console.error('API request failed:', err);
        throw err;
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);