# Retailer-Manufacturer Supply Chain Management System

A full-stack application for managing inventory and orders between retailers and manufacturers.

## Features
- **User Authentication**: JWT-based auth for retailers/manufacturers
- **Inventory Management**: Track stock levels, low stock alerts
- **Order Processing**: Place, track, and fulfill orders
- **Real-time Notifications**: WebSocket-based alerts

## Technologies
- **Frontend**: HTML5, CSS3, JavaScript
- **Backend**: Node.js, Express
- **Database**: MongoDB
- **Authentication**: JWT

## Installation
1. Install Node.js and MongoDB
2. Clone the repository
3. Install dependencies:
   ```bash
   cd server
   npm install